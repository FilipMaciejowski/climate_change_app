import React from "react";

const Story = () => {
  return <div>Story</div>;
};

export default Story;

