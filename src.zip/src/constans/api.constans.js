export default {
  imagesApiUrl: "https://pixabay.com/api/?",
  imagesApiKey: "key=14978488-9df334a9c45671cc0c6bfd08c",
  infoAboutCountryApiUrl: "https://restcountries.eu/rest/v2/name/",
  climateDataApiUrl: "http://climatedataapi.worldbank.org/climateweb/rest/v1/country/cru/tas/decade/"
};


