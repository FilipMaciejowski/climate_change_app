export default {
  imagesApiUrl: "https://pixabay.com/api/?",
  imagesApiKey: "key=14978488-9df334a9c45671cc0c6bfd08c"
};


