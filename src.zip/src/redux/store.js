import { createStore, combineReducers, applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import { location } from './reducers/locationReducer';
import promiseMiddleware from 'redux-promise-middleware';
import logger from 'redux-logger';
import { message } from "antd";


 const rootreducer = combineReducers(
   {location: location}
 )

 /* const errorHandler = store => next => action => {
   const actionType = action.type;
   const actionTypeStatus = actionType.substr(actionType.lastIndexOf("_") + 1);

   if (actionTypeStatus === "REJECTED") {
     message.error("Error, try again later");
   } else if (actionTypeStatus === "FULFILLED") {
     
     message.success("Data fetched");
   } console.log(action, actionTypeStatus);
   return next(action);
 }; */

const store = createStore(
  rootreducer,
  compose(
    applyMiddleware(thunk, promiseMiddleware, logger),
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
  )
);

export default store;